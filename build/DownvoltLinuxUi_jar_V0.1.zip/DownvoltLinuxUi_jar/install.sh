#!/bin/bash
#You can use these ANSI escape codes:
#Black        0;30     Dark Gray     1;30
#Red          0;31     Light Red     1;31
#Green        0;32     Light Green   1;32
#Brown/Orange 0;33     Yellow        1;33
#Blue         0;34     Light Blue    1;34
#Purple       0;35     Light Purple  1;35
#Cyan         0;36     Light Cyan    1;36
#Light Gray   0;37     White         1;37

#Token download c07b8056e9b36fe39c8376e319cfcf983a30b353
clear

RED='\033[0;31m'
GREEN='\033[0;32m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'    # No Color

#cpnstant variable
user=$(whoami)
cpu=$(lscpu)
distro=$(cat /etc/os-release)
title="Install undervolt utility for linux INTEL"

#If no openjdk, i'll install it
function ceckJava(){
  javav=$(java -version);

  #If java is installed skip
  if echo "$javav" | grep -q "openjdk"; then
     echo -e "${BLUE}God, you already have Java ${NC}"
  else
    echo -e "${BLUE}You don't have java... i'll install for you ${NC}"
    sudo apt install default-jre
  fi
}

#if no python3 i'll install it
function ceckPytjon() {
  pyv=$(python3 --version);

  #If Python3 is installed skip
  if echo "$pyv" | grep -q "Python 3."; then
     echo -e "${BLUE}God, you already have Python3 ${NC}"
  else
    echo -e "${BLUE}You don't have Python3... i'll install for you ${NC}"
    sudo apt install default-jre
  fi
}

#Desktop envirorment installer
function procedToInstall() {
    #Update
    sudo apt update

    #Install java
    ceckJava

    #Install python3
    ceckPytjon

    #Set Folder
    rm -rf resource/externaltools/*
    cd resource/externaltools/

    #Download script
    echo -e "${BLUE}Downloading script ${NC}"
    wget https://raw.githubusercontent.com/georgewhewell/undervolt/master/undervolt.py
    wget https://github.com/georgewhewell/undervolt/blob/master/setup.py
    wget https://github.com/georgewhewell/undervolt/blob/master/README.rst
    wget https://github.com/georgewhewell/undervolt/blob/master/LICENSE.txt
    wget https://github.com/georgewhewell/undervolt/blob/master/.travis.yml
    wget https://raw.githubusercontent.com/georgewhewell/undervolt/master/.gitignore

    #Ser permission
    sudo chmod 777 *.*
    cd ..
    cd ..
    sudo chmod 777 *.*
}

function installStart(){
  if (whiptail --title "$title" --yesno "
  This installer will install the following dependeces:
  1) Java jre    --> Package: default-jre
  2) Python 3    --> Package: python3

  Then will download undervolt.py from here:
  https://github.com/georgewhewell/undervolt
  " 15 80); then
      procedToInstall
  else
      echo "Abortin installation"
  fi
}

#if cpu is not an INTEL one
function installAbortCpu() {
  whiptail --title "$title" --msgbox "Your cpu is not supported... I'm sorry but is for INTEL cpu..

Cpu info:
$cpu" 25 78
}

function installAbortDistro() {
  whiptail --title "$title" --msgbox "Your disto is not suppoted... for now it will only work on Debian base distro" 25 78
}

function ceckCPU() {
  #Ceck if cpu is INTEL
  if echo "$cpu" | grep -q "GenuineIntel"; then
    installStart
  else
    installAbortCpu
  fi
}

#ceckDistro
if echo "$distro" | grep -q "ID_LIKE=debian"; then
  ceckCPU
else
  installAbortDistro
fi
