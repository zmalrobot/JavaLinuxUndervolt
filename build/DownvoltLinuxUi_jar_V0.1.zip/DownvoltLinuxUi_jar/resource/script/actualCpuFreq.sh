#!/bin/bash
lscpu | grep MHz
