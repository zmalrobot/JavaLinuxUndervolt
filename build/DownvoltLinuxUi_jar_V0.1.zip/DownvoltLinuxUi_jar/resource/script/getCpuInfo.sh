#!/bin/bash
sudo lscpu
